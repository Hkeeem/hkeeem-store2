import { GoogleGenerativeAI } from "@google/generative-ai"

export async function POST(req: Request) {
  try {
    const { message, offers } = await req.json()
    
    const apiKey = process.env.GEMINI_API_KEY
    if (!apiKey) {
      return Response.json({ reply: "⚠️ لم يتم ضبط مفتاح Gemini. أضف GEMINI_API_KEY في Vercel > Settings > Environment Variables" })
    }

    const genAI = new GoogleGenerativeAI(apiKey)
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" })

    const offersText = offers?.slice(0,10).map((o:any)=>`- ${o.title} (${o.store}) سعره ${o.price} ر.س في ${o.location.district} خصم ${o.discount}%`).join('\n') || "لا يوجد عروض حاليا"

    const systemPrompt = `
أنت مساعد ذكي اسمه "حكيم" لمتجر "عروضكم" في جدة، السعودية.
مهمتك تساعد المستخدم يلقى أقرب العروض.
تتكلم لهجة سعودية خفيفة وودودة ومختصرة.
عندك هذه العروض الحالية:
${offersText}

قواعد:
- إذا سأل عن عطور رد بعطور حكيم
- إذا سأل عن جرير أو بنده رد بالعروض المطابقة
- إذا سأل عن الأقرب رتب حسب المسافة
- لا تخترع عروض غير موجودة
- جاوب باختصار 2-3 أسطر ثم اعرض النتائج
- إذا ما لقيت قل له بنضيف قريبا
`

    const result = await model.generateContent(`${systemPrompt}\n\nسؤال العميل: ${message}\n\nجاوب:`)
    const reply = result.response.text()

    // فلترة بسيطة للنتائج للعرض كبطاقات
    let results = []
    const lower = message.toLowerCase()
    if(lower.includes('عطر')) results = offers.filter((o:any)=>o.title.includes('عطر'))
    else if(lower.includes('جرير')) results = offers.filter((o:any)=>o.store.includes('جرير'))
    else if(lower.includes('بنده')) results = offers.filter((o:any)=>o.store.includes('بنده'))
    else results = offers.slice(0,3)

    return Response.json({ reply, results })
  } catch (e:any) {
    console.error(e)
    return Response.json({ reply: "صار خطأ بسيط في الاتصال مع Gemini، جرب مرة ثانية 🙏", results: [] }, { status: 200 })
  }
}
