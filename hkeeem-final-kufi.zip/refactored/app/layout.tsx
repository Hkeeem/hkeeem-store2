import './globals.css'
export const metadata = { title:'عروضكم - متجر حكيم', description:'أقرب العروض حولك', manifest:'/manifest.json', themeColor:'#B68A2E' }
export default function RootLayout({children}:{children:React.ReactNode}){ return <html lang="ar" dir="rtl"><body>{children}</body></html> }
