export type LatLng = { lat: number; lng: number }
export type City = { name: string; label: string; lat: number; lng: number }
export type OfferLocation = LatLng & { address: string; district: string }
export type Offer = {
  id: number
  title: string
  store: string
  price: number
  old_price: number
  discount: number
  image: string
  isOwn?: boolean
  location: OfferLocation
}
export type OfferWithDistance = Offer & { distance: number | null }
export type Tab = 'home' | 'stores' | 'haraj' | 'office' | 'hkeem'
export type LegalType = 'privacy' | 'terms' | 'contact' | 'share' | null
