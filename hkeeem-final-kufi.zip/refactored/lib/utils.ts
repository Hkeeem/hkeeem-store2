import type { LatLng } from '@/types'

export function haversine(a: LatLng, b: LatLng): number {
  const R = 6371
  const dLat = (b.lat - a.lat) * Math.PI / 180
  const dLng = (b.lng - a.lng) * Math.PI / 180
  const s = Math.sin(dLat/2)**2 + Math.cos(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*Math.sin(dLng/2)**2
  return 2 * R * Math.asin(Math.sqrt(s))
}
export const formatDistance = (k: number) => k < 1 ? `${Math.round(k*1000)} م` : `${k.toFixed(1)} كم`
export const formatPrice = (n: number) => `${n.toLocaleString('ar-SA')} ر.س`
