'use client'
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'
import L from 'leaflet'
import type { OfferWithDistance } from '@/types'
import { useEffect } from 'react'

// Fix default icon
delete (L.Icon.Default.prototype as any)._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
})

type Props = { offers: OfferWithDistance[]; center: { lat:number; lng:number } }

export default function LeafletMap({ offers, center }: Props) {
  return (
    <MapContainer center={[center.lat, center.lng]} zoom={13} style={{ height:'calc(100vh - 56px)', width:'100%' }}>
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution="&copy; OpenStreetMap" />
      {offers.map(o=>(
        <Marker key={o.id} position={[o.location.lat, o.location.lng]}>
          <Popup><b>{o.title}</b><br/>{o.store} - {o.location.district}</Popup>
        </Marker>
      ))}
    </MapContainer>
  )
}
