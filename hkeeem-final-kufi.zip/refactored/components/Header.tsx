import Image from 'next/image'

type Props = {
  currentLabel: string | null
  user: any
  onOpenAuth: () => void
  onOpenShare: () => void
}

export default function Header({ currentLabel, user, onOpenAuth, onOpenShare }: Props) {
  return (
    <header className="sticky top-0 z-30 backdrop-blur-xl bg-[#FFFCF6]/90 border-b border-[#EADFC9]">
      <div className="max-w-7xl mx-auto px-4 h-16 flex justify-between items-center">
        <div className="flex items-center gap-2.5">
          <Image src="/hkeeem-icon.png" alt="حكيم" width={36} height={36} className="rounded-xl border border-[#EADFC9] bg-white object-contain p-1" />
          <span className="font-black text-lg">عروض<span className="text-[#B68A2E]">كم</span></span>
          {currentLabel && <span className="hidden md:inline-flex px-3 py-1 rounded-full text-xs font-bold border bg-[#FFF8E6] text-[#7A5A16] border-[#EADFC9]">{currentLabel}</span>}
        </div>
        <div className="flex items-center gap-2">
          <button onClick={onOpenShare} aria-label="مشاركة" className="w-9 h-9 rounded-full border bg-white border-[#EADFC9] grid place-items-center">↗️</button>
          <button onClick={onOpenAuth} className="px-4 h-10 rounded-full border bg-white border-[#EADFC9] text-xs font-black">
            {user ? `👋 ${user.user_metadata?.name || user.email || 'حسابي'}` : '👤 دخول'}
          </button>
        </div>
      </div>
    </header>
  )
}
