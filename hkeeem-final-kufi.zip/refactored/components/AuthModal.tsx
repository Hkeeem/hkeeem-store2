'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabase'

type Props = { open: boolean; onClose: () => void; onToast: (m:string)=>void }

export default function AuthModal({ open, onClose, onToast }: Props){
  const [email,setEmail]=useState(''); const [loading,setLoading]=useState(false)
  if(!open) return null
  const login = async()=>{
    if(!email.includes('@')){ onToast('أدخل إيميل صحيح'); return }
    setLoading(true)
    const { error } = await supabase.auth.signInWithOtp({ email, options:{ emailRedirectTo: typeof window!=='undefined'?window.location.origin:undefined } })
    setLoading(false)
    if(error){ onToast(error.message) } else { onToast('تم إرسال رابط الدخول لإيميلك ✉️'); onClose() }
  }
  return (
    <div className="fixed inset-0 z-50 bg-black/50 grid place-items-center p-4" onClick={onClose}>
      <div className="w-full max-w-[360px] rounded-3xl bg-[#FFFCF6] border border-[#EADFC9] p-6" onClick={e=>e.stopPropagation()}>
        <div className="flex justify-between"><h2 className="font-black">تسجيل الدخول الحقيقي</h2><button onClick={onClose} className="w-8 h-8 rounded-full border">✕</button></div>
        <p className="text-xs text-zinc-500 mt-2">نرسل لك رابط سحري بدون كلمة مرور - مدعوم بـ Supabase Auth</p>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="example@gmail.com" className="w-full mt-4 h-12 px-4 rounded-2xl border-2 border-[#EADFC9] text-sm" />
        <button onClick={login} disabled={loading} className="w-full mt-3 h-12 rounded-full text-white font-black text-sm bg-[#7A5A16] disabled:opacity-50">{loading?'جاري الإرسال...':'إرسال رابط الدخول'}</button>
        <div className="text-[11px] text-zinc-400 mt-3 text-center">آمن ومشفر عبر Supabase</div>
      </div>
    </div>
  )
}
