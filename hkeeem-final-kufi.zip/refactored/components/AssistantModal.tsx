'use client'
import { useState } from 'react'
import Image from 'next/image'
import type { OfferWithDistance } from '@/types'
import { formatPrice } from '@/lib/utils'

type Msg = { role:'user'|'bot'; text:string; results?:any[] }

export default function AssistantModal({ open, onClose, offers }: { open:boolean; onClose:()=>void; offers: OfferWithDistance[] }){
  const [input,setInput]=useState(''); const [msgs,setMsgs]=useState<Msg[]>([{role:'bot',text:'أهلاً أنا حكيم 🤖 مدعوم بـ Gemini، اسألني عن أقرب عروض'}]); const [loading,setLoading]=useState(false)
  if(!open) return null
  const send = async()=>{
    if(!input.trim()||loading) return
    const q=input; setInput(''); setMsgs(m=>[...m,{role:'user',text:q}]); setLoading(true)
    try{
      const r=await fetch('/api/gemini',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:q, offers})})
      const d=await r.json(); setMsgs(m=>[...m,{role:'bot',text:d.reply, results:d.results}])
    }catch{ setMsgs(m=>[...m,{role:'bot',text:'صار خطأ بسيط، جرب مرة ثانية'}]) } finally{ setLoading(false) }
  }
  return (
    <div className="fixed inset-0 z-50 bg-black/40 grid place-items-end" onClick={onClose}>
      <div className="w-full max-w-md h-[75vh] bg-[#FFFCF6] rounded-t-3xl border-t flex flex-col" onClick={e=>e.stopPropagation()}>
        <div className="p-4 border-b flex justify-between"><b>حكيم - Gemini 1.5</b><button onClick={onClose} className="w-8 h-8 rounded-full border">✕</button></div>
        <div className="flex-1 overflow-auto p-4 space-y-3">{msgs.map((m,i)=><div key={i} className={`${m.role==='user'?'mr-auto bg-black text-white':'bg-white border'} max-w-[85%] rounded-2xl px-4 py-3 text-sm`}>{m.text}{m.results&&<div className="mt-2 grid gap-2">{m.results.map((o:any)=><div key={o.id} className="flex gap-2 p-2 rounded-xl bg-[#FDF6E8] border"><Image src={o.image} alt={o.title} width={48} height={48} className="rounded-xl object-cover w-12 h-12"/><div className="text-xs"><div className="font-bold">{o.title}</div><div className="font-black text-[#7A5A16]">{formatPrice(o.price)}</div></div></div>)}</div>}</div>)}{loading&&<div className="text-xs text-zinc-400">حكيم يكتب...</div>}</div>
        <div className="p-3 border-t flex gap-2"><input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()} placeholder="اسأل..." className="flex-1 h-11 px-4 rounded-full border-2 bg-[#FDF6E8] text-sm"/><button onClick={send} className="w-11 h-11 rounded-full bg-[#7A5A16] text-white">↑</button></div>
      </div>
    </div>
  )
}
