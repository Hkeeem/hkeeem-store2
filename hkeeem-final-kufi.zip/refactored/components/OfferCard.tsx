import Image from 'next/image'
import { memo } from 'react'
import type { OfferWithDistance } from '@/types'
import { formatDistance, formatPrice } from '@/lib/utils'

type Props = {
  offer: OfferWithDistance
  onNavigate: () => void
  onMap: () => void
}

function OfferCard({ offer, onNavigate, onMap }: Props) {
  return (
    <article className="rounded-2xl border bg-white border-[#EADFC9] overflow-hidden flex flex-col">
      <div className="relative">
        <Image src={offer.image} alt={offer.title} width={400} height={300} className="h-36 w-full object-cover" />
        <span className="absolute top-2.5 right-2.5 px-2.5 py-1 rounded-full text-xs font-black text-white bg-[#7A5A16]">-{offer.discount}%</span>
        {offer.distance !== null && <span className="absolute top-2.5 left-2.5 px-2 py-1 rounded-full bg-black/80 text-white text-xs font-bold">📍 {formatDistance(offer.distance)}</span>}
      </div>
      <div className="p-3 flex flex-col flex-1">
        <div className="text-xs text-zinc-500">🏬 {offer.store} • {offer.location.district}</div>
        <h3 className="font-bold text-sm mt-1 min-h-10 line-clamp-2">{offer.title}</h3>
        <div className="flex gap-1.5 mt-auto pt-3">
          <button onClick={onNavigate} className="flex-1 h-9 rounded-full text-xs font-black text-white bg-[#7A5A16]">الوصول 🚗</button>
          <button onClick={onMap} className="w-9 h-9 rounded-full border bg-[#FFF8E6] border-[#EADFC9]">🗺️</button>
        </div>
        <div className="flex items-baseline gap-1 mt-2"><span className="font-black text-sm text-[#7A5A16]">{formatPrice(offer.price)}</span><span className="text-xs line-through text-zinc-400">{formatPrice(offer.old_price)}</span></div>
      </div>
    </article>
  )
}
export default memo(OfferCard)
