import type { Tab } from '@/types'

const TABS: { k: Tab; l: string; i: string }[] = [
  { k: 'home', l: 'الرئيسية', i: '🏠' },
  { k: 'stores', l: 'المتاجر', i: '🏬' },
  { k: 'haraj', l: 'حراج', i: '🔨' },
  { k: 'office', l: 'مكتبي', i: '📁' },
  { k: 'hkeem', l: 'متجر حكيم', i: '💛' },
]

type Props = { tab: Tab; setTab: (t: Tab) => void }

export default function BottomNav({ tab, setTab }: Props) {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-30 bg-white/95 backdrop-blur-xl border-t border-[#EADFC9] h-20">
      <div className="max-w-7xl mx-auto grid grid-cols-5 h-full">
        {TABS.map(t => (
          <button key={t.k} onClick={() => setTab(t.k)} className={`flex flex-col items-center justify-center gap-1 text-xs font-bold ${tab===t.k?'text-[#7A5A16]':'text-zinc-500'}`}>
            <span className={`w-8 h-8 rounded-full grid place-items-center ${tab===t.k?'bg-[#FFF3CC] border border-[#E9C86A]':''}`}>{t.i}</span>{t.l}
          </button>
        ))}
      </div>
    </nav>
  )
}
