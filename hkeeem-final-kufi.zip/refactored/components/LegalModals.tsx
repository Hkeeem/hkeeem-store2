import type { LegalType } from '@/types'

type Props = { type: LegalType; onClose: ()=>void; onToast:(m:string)=>void }

export default function LegalModals({ type, onClose, onToast }: Props){
  if(!type) return null
  const Wrap = ({children, title}:{children:any,title:string})=>(<div className="fixed inset-0 z-[60] bg-black/60 p-4 grid place-items-center" onClick={onClose}><div className="w-full max-w-lg max-h-[85vh] overflow-auto rounded-3xl bg-white p-6" onClick={e=>e.stopPropagation()}><div className="flex justify-between items-center mb-4"><h2 className="font-black text-lg">{title}</h2><button onClick={onClose} className="w-8 h-8 rounded-full border">✕</button></div>{children}</div></div>)
  if(type==='privacy') return <Wrap title="🔒 سياسة الخصوصية"><div className="text-sm leading-7 text-zinc-700 space-y-3"><p>نحترم خصوصيتك. نجمع الموقع بإذنك فقط لعرض أقرب العروض.</p><p>لا نبيع بياناتك. يمكنك حذف حسابك عبر تواصل معنا.</p><p className="text-xs text-zinc-400">آخر تحديث: 14 يوليو 2026</p></div></Wrap>
  if(type==='terms') return <Wrap title="📄 الشروط والأحكام"><div className="text-sm leading-7 text-zinc-700"><p>الأسعار قابلة للتغيير. حراج مسؤولية البائع والمشتري. متجر حكيم منتجات أصلية.</p></div></Wrap>
  if(type==='contact') return <Wrap title="💬 تواصل معنا"><div className="space-y-3"><a href="https://wa.me/966500000000" target="_blank" className="block p-3 rounded-2xl bg-[#E8FFF0] border">واتساب: 966500000000</a><button onClick={()=>{onToast('تم النسخ'); onClose()}} className="w-full h-11 rounded-full bg-[#7A5A16] text-white font-black">إغلاق</button></div></Wrap>
  if(type==='share') return <Wrap title="🔗 شارك التطبيق"><div className="grid grid-cols-3 gap-3"><button onClick={()=>window.open(`https://wa.me/?text=${encodeURIComponent(window.location.href)}`,'_blank')} className="p-3 rounded-xl bg-[#25D366] text-white">واتساب</button><button onClick={()=>window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(window.location.href)}`,'_blank')} className="p-3 rounded-xl bg-black text-white">X</button><button onClick={async()=>{await navigator.clipboard.writeText(window.location.href); onToast('تم نسخ الرابط');}} className="p-3 rounded-xl bg-[#EADFC9]">نسخ</button></div></Wrap>
  return null
}
