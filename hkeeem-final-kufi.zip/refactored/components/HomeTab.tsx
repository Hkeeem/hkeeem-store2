import type { OfferWithDistance, City } from '@/types'
import OfferCard from './OfferCard'
import SearchBar from './SearchBar'
import { useMemo } from 'react'

const CITIES: City[] = [
  { name:'جدة', label:'حي الروضة، جدة', lat:21.543333, lng:39.172778 },
  { name:'مكة', label:'العزيزية، مكة', lat:21.389082, lng:39.857912 },
  { name:'الرياض', label:'العليا، الرياض', lat:24.713552, lng:46.675297 },
  { name:'الدمام', label:'الشاطئ، الدمام', lat:26.42068, lng:50.088795 },
]

type Props = {
  offers: OfferWithDistance[]
  searchQ: string
  setSearchQ: (v:string)=>void
  onToast: (m:string)=>void
  radiusKm: number
  setRadiusKm: (n:number)=>void
  nearbyOnly: boolean
  setNearbyOnly: (b:boolean)=>void
  cityManual: City | null
  setCityManual: (c:City)=>void
  onLocate: ()=>void
  onMap: (o:OfferWithDistance)=>void
  onOpenAllMap: ()=>void
}

export default function HomeTab({ offers, searchQ, setSearchQ, onToast, radiusKm, setRadiusKm, nearbyOnly, setNearbyOnly, cityManual, setCityManual, onLocate, onMap, onOpenAllMap }: Props){
  return (
    <>
      <div className="mt-4 flex gap-2"><button onClick={onLocate} className="flex-1 h-12 rounded-2xl bg-[#1F1B16] text-white text-sm font-black">📍 العروض حولي الآن</button><button onClick={onOpenAllMap} className="px-4 h-12 rounded-2xl bg-white border text-sm font-bold">🗺️ الخريطة</button></div>
      <div className="mt-3"><SearchBar value={searchQ} onChange={setSearchQ} onToast={onToast} /></div>
      <div className="mt-4 flex flex-wrap gap-2">{CITIES.map(c=><button key={c.name} onClick={()=>setCityManual(c)} className={`px-4 h-9 rounded-full text-xs font-bold border ${cityManual?.name===c.name?'bg-[#B68A2E] text-white':'bg-white'}`}>{c.name}</button>)}<div className="flex gap-1.5">{[1,3,5,10].map(k=><button key={k} onClick={()=>{setRadiusKm(k); setNearbyOnly(true)}} className={`px-3 h-9 rounded-full text-xs font-bold border ${nearbyOnly&&radiusKm===k?'bg-black text-white':'bg-white'}`}>داخل {k} كم</button>)}</div></div>
      <h2 className="mt-6 mb-3 font-black">كل العروض ({offers.length})</h2>
      <section className="grid grid-cols-2 md:grid-cols-4 gap-3">{offers.map(o=><OfferCard key={o.id} offer={o} onNavigate={()=>window.open(`https://www.google.com/maps/dir/?api=1&destination=${o.location.lat},${o.location.lng}`,'_blank')} onMap={()=>onMap(o)} />)}</section>
    </>
  )
}
