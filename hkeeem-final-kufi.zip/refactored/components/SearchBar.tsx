'use client'
import { useRef, useState } from 'react'
import { Html5Qrcode } from 'html5-qrcode'

type Props = { value: string; onChange: (v: string) => void; onToast: (m: string) => void }

export default function SearchBar({ value, onChange, onToast }: Props) {
  const [scanning, setScanning] = useState(false)
  const qrRef = useRef<Html5Qrcode | null>(null)

  const stop = async () => { try{ await qrRef.current?.stop(); await qrRef.current?.clear()}catch{} setScanning(false) }
  const start = async () => {
    setScanning(true)
    setTimeout(async()=>{
      try{
        const r = new Html5Qrcode('reader')
        qrRef.current = r
        await r.start({ facingMode:'environment' }, { fps:10, qrbox:{width:250,height:250} }, (d)=>{ onChange(d); stop(); onToast(`تم مسح: ${d}`) }, ()=>{})
      }catch{ setScanning(false); onToast('تعذر فتح الكاميرا') }
    },200)
  }

  return (
    <div>
      <div className="flex gap-2">
        <input value={value} onChange={e=>onChange(e.target.value)} placeholder="ابحث عن عرض أو متجر أو باركود..." className="flex-1 h-12 px-4 rounded-2xl border-2 border-[#EADFC9] bg-white text-sm outline-none focus:border-[#B68A2E]" />
        <button onClick={scanning?stop:start} className="px-5 h-12 rounded-2xl text-white text-sm font-black bg-[#7A5A16]">{scanning?'إيقاف':'مسح'}</button>
      </div>
      {scanning && <div className="mt-3 rounded-2xl overflow-hidden border-2 border-[#EADFC9] bg-black"><div id="reader" className="w-full" /></div>}
    </div>
  )
}
